import java.io.*;
import static java.lang.Integer.parseInt;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class displayall extends HttpServlet {
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
int n=parseInt(request.getParameter("one"));

try{
   
    Class.forName("com.mysql.jdbc.Driver");
   
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
Statement stmt=con.createStatement();
if(n==1234)
{
ResultSet rs=stmt.executeQuery("select * from employee");
while(rs.next())
{
        out.println("<html>");
        out.println("<body background='images/mainscreen.jpg'>");
        out.println("<br><br><br><br><br><br><br><br><br>");
        out.println("<table align='center' border='1px' cellpadding='7px'>");
        out.println("<tr><td>employeeid</td><td>firstname</td><td>lastname</td><td>username</td><td>employee_type</td><td>date_of_birth</td><td>date_of_joining</td><td>Designation</td><td>gender</td><td>salary</td><td>marital_status</td><td>contact_number</td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td>");
        out.println(rs.getInt(1));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(2));
        out.println("</td>");
       out.println("<td>");
        out.println(rs.getString(3));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(4));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(6));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(7));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(8));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(9));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(10));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(11));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(12));
        out.println("</td>");
        out.println("<td>");
        out.println(rs.getString(14));
        out.println("</td>");
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
}

        
    }
else
{
    out.println("<center><b>");
    out.println("your passcode is not matched please enter correct passcode");
    out.println("</b></center>");
    response.setHeader("Refresh","5;URL=display.html");
}

}
catch(ClassNotFoundException | SQLException |NullPointerException e)
{}

}
}