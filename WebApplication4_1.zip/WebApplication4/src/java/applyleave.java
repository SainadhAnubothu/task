import java.io.*;
import static java.lang.Integer.parseInt;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class applyleave extends HttpServlet {
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
int empid=parseInt(request.getParameter("emp_id"));
String f_date=request.getParameter("from_date");
String t_date=request.getParameter("to_date");
int no_days=parseInt(request.getParameter("numdays"));
try{
   
    Class.forName("com.mysql.jdbc.Driver");
   
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
PreparedStatement ps=con.prepareStatement("insert into leaves values(?,?,?,?,?)");
ps.setInt(1,empid);
ps.setString(2,f_date);
ps.setString(3,t_date);
ps.setInt(4,no_days);
ps.setString(5,"NULL");
ps.executeUpdate();
out.println("<center>");
    out.println("leave applied sucessfully");
    out.println("</center>");
    response.setHeader("Refresh","5;URL=user.html");
}
catch(Exception e)
{
out.println(e);
}

}
}