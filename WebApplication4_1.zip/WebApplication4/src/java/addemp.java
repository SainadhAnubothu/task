import java.io.*;
import static java.lang.Integer.parseInt;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class addemp extends HttpServlet {
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
int empid=parseInt(request.getParameter("id"));
String fname=request.getParameter("f_name");
String lname=request.getParameter("l_name");
String uname=request.getParameter("u_name");
String pword=request.getParameter("pass");
String emptype=request.getParameter("type");
String date_birth=request.getParameter("dob");
String date_join=request.getParameter("doj");
String designation=request.getParameter("des");
String gender=request.getParameter("gender");
int salary=parseInt(request.getParameter("sal"));
String marrital_status=request.getParameter("status");
String address=request.getParameter("area");
String phno=request.getParameter("phno");
try{
   
    Class.forName("com.mysql.jdbc.Driver");
   
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
PreparedStatement ps2=con.prepareStatement("insert into user_login values(?,?,?,?)");

ps.setInt(1,empid);
ps.setString(2,fname);
ps.setString(3,lname);
ps.setString(4,uname);
ps.setString(5,pword);
ps.setString(6,emptype);
ps.setString(7,date_birth);
ps.setString(8,date_join);
ps.setString(9,designation);
ps.setString(10,gender);
ps.setInt(11,salary);
ps.setString(12,marrital_status);
ps.setString(13,address);
ps.setString(14,phno);
ps2.setInt(1,empid);
ps2.setString(2,uname);
ps2.setString(3,pword);
ps2.setString(4,emptype);
int n=ps.executeUpdate();
int n1=ps2.executeUpdate();
if(n>0 && n1>0)
{
    out.println("<center>");
    out.println("added sucessfully");
    out.println("</center>");
    response.setHeader("Refresh","5;URL=admin.html");
}


}
catch(ClassNotFoundException | SQLException |NullPointerException e)
{}

}
}