import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpSession;

public class NewServlet extends HttpServlet{
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
String fname=request.getParameter("name");
String pword=request.getParameter("pwd");

try{
   
    Class.forName("com.mysql.jdbc.Driver");
   
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select * from user_login");
while(rs.next())
{
    
    
   if(fname.equals(rs.getString(2)) && pword.equals(rs.getString(3)))
    {
       
        if("admin".equals(rs.getString(4)))
        {
                 response.sendRedirect("admin.html");
                  HttpSession session=request.getSession(true);
                  session.setAttribute("name",fname);
                  session.setAttribute("password",pword);
        }
        else if("user".equals(rs.getString(4)))
        {
                response.sendRedirect("user.html");
                HttpSession session=request.getSession(true);
                session.setAttribute("name",fname);
                session.setAttribute("password",pword);
        }
    }
   else
   {
       out.println("wrong password");
        response.setHeader("Refresh","5;URL=login.html");
   }
}
}
catch(Exception e)
{
out.println(e);
}

}
}