import java.io.*;
import static java.lang.Integer.parseInt;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class cp extends HttpServlet {
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
String oldpassword=request.getParameter("oldpass");
String newpassword=request.getParameter("newpass");

try{
   
   
    Class.forName("com.mysql.jdbc.Driver");
   
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
 HttpSession session=request.getSession();
String name1=(String)session.getAttribute("name");
String password1=(String)session.getAttribute("password");
if(password1.equals(oldpassword))
{
PreparedStatement stmt=con.prepareStatement("select u_id from user_login where u_name=? && u_password=?");
stmt.setString(1, name1);
stmt.setString(2, password1); 
ResultSet rs1=stmt.executeQuery();
rs1.next();
out.println(name1);
out.println(password1);
int number=rs1.getInt(1);
out.println(number);
Statement stmt1=con.createStatement();
PreparedStatement ps=con.prepareStatement("update employee SET password=? where emp_id=?");
ps.setString(1,password1);
ps.setInt(2,number);
ps.executeUpdate();
ps.close();

PreparedStatement ps1=con.prepareStatement("update user_login SET u_password=? where u_id=?");
ps1.setString(1,password1);
ps1.setInt(2,number);
ps1.executeUpdate();
ps1.close();
out.println("updated sucessfully");
}
else
{
    out.println("password not matched");
    response.setHeader("Refresh","5;URL=changepassword.html");
    
}
}
catch(Exception e)
{
out.println(e);
}

}

}