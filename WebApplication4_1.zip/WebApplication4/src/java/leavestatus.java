import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpSession;

public class leavestatus extends HttpServlet {
@Override
public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException,NullPointerException{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
try{  
    Class.forName("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/ems", "root", "root");
 HttpSession session=request.getSession(true);
String name1=(String)session.getAttribute("name");
String password1=(String)session.getAttribute("password");

PreparedStatement stmt=con.prepareStatement("select u_id from user_login where u_name=? && u_password=?");
stmt.setString(1, name1);
stmt.setString(2, password1);

ResultSet rs1=stmt.executeQuery();
rs1.next();
int number=rs1.getInt(1);
PreparedStatement stmt1=con.prepareStatement("select status from leaves where emp_id=?");
stmt1.setInt(1,number);
ResultSet rs=stmt1.executeQuery();

/*PreparedStatement stmt1=con.prepareStatement("select * from employee where(emp_id=?)");
stmt1.setInt(1,rs1.getInt(1));
ResultSet rs=stmt1.executeQuery();*/
  //run 
  while(rs.next())
  {
       out.println(rs.getString(1));
  }
}
catch(Exception e)
{
out.println(e);
}

}
}