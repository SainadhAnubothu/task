package com.cg.teacherplan.bean;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries(@NamedQuery(name="getAllPlans",query="select t from TeacherBean t"))
public class TeacherBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer planId;
	private String facultyName;
	private String dates;
	private String expertIn;
	private String period;
	private String comments;
	private String emailId;
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public String getExpertIn() {
		return expertIn;
	}
	public void setExpertIn(String expertIn) {
		this.expertIn = expertIn;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public TeacherBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TeacherBean [planId=" + planId + ", facultyName=" + facultyName
				+ ", dates=" + dates + ", expertIn=" + expertIn + ", period="
				+ period + ", comments=" + comments + ", emailId=" + emailId
				+ "]";
	}
	
}
