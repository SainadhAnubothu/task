package com.cg.teacherplan.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.teacherplan.bean.TeacherBean;
import com.cg.teacherplan.service.ITeacherService;

@Controller
public class TeacherController {
	@Autowired
	public ITeacherService rserv;
	@RequestMapping("/index")
	public String checkDetails(Model m)
	{
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		return "home";
	}
	@RequestMapping(value="/addTrainee")
	public String addTrainee(Model m)
	{
		System.out.println("=======================================================================");
		TeacherBean bean=new TeacherBean();
		m.addAttribute("ins", bean);
		
		List<String> periods = new ArrayList<String>();
		periods.add("Maths");
		periods.add("Science");
		periods.add("social");
		periods.add("physics");
		m.addAttribute("periods",periods);
		return "planentry";
	}
	@RequestMapping(value="/insertDetails",method=RequestMethod.POST)
	public String insertPlan(@ModelAttribute("ins") TeacherBean bean,Model m)
	{
		Integer res=0;
		System.out.println(bean);
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String d=bean.getDates();
		LocalDate l=LocalDate.parse(d, f);
		/*bean.setDates(dates);*/
		res=rserv.insertPlans(bean);
		System.out.println(bean.getPlanId());
		m.addAttribute("result", res);
		System.out.println(res);
		return "success";
	}
	
	@RequestMapping("/getAllTrainees")
	public String getAllPlans(Model m)
	{
		ArrayList<TeacherBean> arr=rserv.getAll();
		m.addAttribute("alldetails", arr);
		System.out.println(arr);
		return "viewplans";
	}
	@RequestMapping(value="/getPlan")
	public String getPlan(Model m)
	{
		TeacherBean bean=new TeacherBean();
		m.addAttribute("gets", bean);
		return "viewoneplan";
	}
	@RequestMapping(value="/getSinglePlan",method=RequestMethod.POST)
	public String getSinglePlan(@ModelAttribute("gets") TeacherBean bean,Model m)
	{
		TeacherBean arr=rserv.getPlan(bean.getPlanId());
		m.addAttribute("siglerow", arr);
		System.out.println(arr);
		return "viewoneplan";
	}
}
