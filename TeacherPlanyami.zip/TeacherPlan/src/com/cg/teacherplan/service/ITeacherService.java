package com.cg.teacherplan.service;

import java.util.ArrayList;

import com.cg.teacherplan.bean.TeacherBean;

public interface ITeacherService {
		public Integer insertPlans(TeacherBean bean);
		public ArrayList<TeacherBean> getAll();
		public TeacherBean getPlan(Integer planId);
}
