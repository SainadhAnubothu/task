package com.cg.teacherplan.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.teacherplan.bean.TeacherBean;
import com.cg.teacherplan.dao.ITeacherDao;

@Service
public class TeacherServiceImpl implements ITeacherService{

	@Autowired
	ITeacherDao tdao;
	@Override
	public Integer insertPlans(TeacherBean bean) {
		// TODO Auto-generated method stub
		System.out.println("inservice"+bean);
		return tdao.insertPlans(bean);
	}

	@Override
	public ArrayList<TeacherBean> getAll() {
		// TODO Auto-generated method stub
		return tdao.getAll();
	}

	@Override
	public TeacherBean getPlan(Integer planId) {
		// TODO Auto-generated method stub
		return tdao.getPlan(planId);
	}

}
