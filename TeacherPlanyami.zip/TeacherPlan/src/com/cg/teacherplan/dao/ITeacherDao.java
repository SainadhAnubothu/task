package com.cg.teacherplan.dao;

import java.util.ArrayList;

import com.cg.teacherplan.bean.TeacherBean;

public interface ITeacherDao {
	public Integer insertPlans(TeacherBean bean);
	public ArrayList<TeacherBean> getAll();
	public TeacherBean getPlan(Integer planId);
}
