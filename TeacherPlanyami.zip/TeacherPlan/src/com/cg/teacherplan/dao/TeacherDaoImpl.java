package com.cg.teacherplan.dao;

import java.util.ArrayList;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.teacherplan.bean.TeacherBean;
@Repository
@Transactional
public class TeacherDaoImpl implements ITeacherDao{

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Integer insertPlans(TeacherBean bean) {
		// TODO Auto-generated method stub
		System.out.println("in dao"+bean);
		
		entityManager.persist(bean);
		entityManager.flush();
		System.out.println("in dao"+bean.getPlanId());
		 Query query = entityManager.createQuery("SELECT t.planId FROM TeacherBean t order by planId desc");
		 
		return query.getFirstResult();
	
	}

	@Override
	public ArrayList<TeacherBean> getAll() {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("getAllPlans");
		ArrayList<TeacherBean> arr=(ArrayList<TeacherBean>) query.getResultList();
		return arr;
	}

	@Override
	public TeacherBean getPlan(Integer planId) {
		// TODO Auto-generated method stub
		 Query query = entityManager.createQuery("SELECT t FROM TeacherBean t where t.planId=:planId");
		 query.setParameter("planId", planId);
		 List list=query.getResultList();
		 System.out.println(list);
		return (TeacherBean) list;
	}

}
