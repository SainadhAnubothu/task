package com.cg.employeemaintenancesystem.dao;

import java.util.ArrayList;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;
import com.cg.employeemaintenancesystem.entity.UserMaster;

public interface IEMSDao{
	public ArrayList<UserMaster> checkLoginCredentials(String userName,String userPassword); 
	public String adminAddEmployee(Employee employee);
	public String adminModifyEmployee(Employee employee);
	public ArrayList<Employee> adminDisplayAllEmployees();
	public ArrayList<LeaveHistory> adminLeaveDecision(String userId,String decision);
	public ArrayList<Employee> userIdSearchEmployee(String employeeId);
	public ArrayList<Employee> userFirstNameSearchEmployee(String firstName);
	public ArrayList<Employee> userLastNameSearchEmployee(String lastName);
	public ArrayList<Employee> userGradeSearchEmployee(String gradeCode);
	public ArrayList<Employee> userDepartmentSearchEmployee(String departmentName);
	public ArrayList<Employee> userMaritalStatusSearchEmployee(String maritalStatus);
	public Integer userApplyLeave(LeaveHistory leaveHistory);
	public ArrayList<LeaveHistory> adminApproveLeave(Integer leaveId);
	public ArrayList<LeaveHistory> adminRejectLeave(Integer leaveId);
}
