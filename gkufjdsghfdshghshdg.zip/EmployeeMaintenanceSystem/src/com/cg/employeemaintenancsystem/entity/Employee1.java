package com.cg.employeemaintenancsystem.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
/*import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;*/
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="Employee")
/*@NamedQueries({@NamedQuery(name="displayAll",query="select employee from Employee employee"),
	@NamedQuery(name="idSearch",query="select employee from Employee employee where employee.employeeId=:employeeId"),
	@NamedQuery(name="firstNameSearch",query="select employee from Employee employee where employee.firstName=:firstName"),
	@NamedQuery(name="lastNameSearch",query="select employee from Employee employee where employee.lastName=:lastName"),
	@NamedQuery(name="gradeSearch",query="select employee from Employee employee where employee.grade=:grade"),
	@NamedQuery(name="maritalStatusSearch",query="select employee from Employee employee where employee.maritalStatus=:maritalStatus")
})*/
public class Employee1 implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Employee1() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@Column(name="Emp_id")
	private String employeeId;
	@Column(name="Emp_First_Name")
	private String firstName;
	@Column(name="Emp_Last_Name")
	private String lastName;
	@Column(name="Emp_Designation")
	private String designation;
	@Column(name="Emp_Basic")
	private Double basicSalary;
	@Column(name="Emp_Gender")
	private String gender;
	@Column(name="Emp_Marital_Status")
	private String maritalStatus;
	@Column(name="Emp_Home_Address")
	private String homeAddress;
	@Column(name="Emp_Contact_Num")
	private String contactNum;
	@Column(name="Mgr_Id")
	private String mgrId;
	@Column(name="Emp_Dept_Id")
	private Integer departmentId;
	@Column(name="Emp_Grade")
	private String grade;
	@Column(name="Emp_Date_of_Birth")
	private Date dateOfBirth;
	@Column(name="Emp_Date_of_Joining")
	private Date dateOfJoining;
	@Transient
	private String employeeDOB;
	@Transient
	private String employeeDOJ;
	@Transient
	private String deptId;
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getContactNum() {
		return contactNum;
	}
	public void setContactNum(String contactNum) {
		this.contactNum = contactNum;
	}
	public String getMgrId() {
		return mgrId;
	}
	public void setMgrId(String mgrId) {
		this.mgrId = mgrId;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getEmployeeDOB() {
		return employeeDOB;
	}
	public void setEmployeeDOB(String employeeDOB) {
		this.employeeDOB = employeeDOB;
	}
	public String getEmployeeDOJ() {
		return employeeDOJ;
	}
	public void setEmployeeDOJ(String employeeDOJ) {
		this.employeeDOJ = employeeDOJ;
	}
	
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
/*	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", designation="
				+ designation + ", basicSalary=" + basicSalary + ", gender="
				+ gender + ", maritalStatus=" + maritalStatus
				+ ", homeAddress=" + homeAddress + ", contactNum=" + contactNum
				+ ", mgrId=" + mgrId + ", departmentId=" + departmentId
				+ ", grade=" + grade + ", dateOfBirth=" + dateOfBirth
				+ ", dateOfJoining=" + dateOfJoining + ", employeeDOB="
				+ employeeDOB + ", employeeDOJ=" + employeeDOJ + "]";
	}*/
	
}

