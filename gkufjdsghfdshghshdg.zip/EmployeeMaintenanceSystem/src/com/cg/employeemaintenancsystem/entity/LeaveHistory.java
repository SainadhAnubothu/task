package com.cg.employeemaintenancsystem.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="leave_history")
public class LeaveHistory implements Serializable{

	public LeaveHistory() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name = "Leave_Id")
	private Integer leaveId;
	@Column(name = "Emp_Id")
	private String empId;
	@Column(name = "Leave_Balance")
	private Integer leaveBalance;
	@Column(name = "NoOfDays_Applied")
	private Integer NoOfDaysApplied;
	@Column(name = "Date_From")
	private Date dateFrom;
	@Column(name = "Date_To")
	private Date dateTo;
	@Column(name="status")
	private String status;
	@Column(name="Applied_Date")
	private Date appliedDate;
	@Transient
	private String leaveAppliedDate;
	@Transient
	private String leaveDateFrom;
	@Transient
	private String leaveDateTo;
	public Integer getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public Integer getLeaveBalance() {
		return leaveBalance;
	}
	public void setLeaveBalance(Integer leaveBalance) {
		this.leaveBalance = leaveBalance;
	}
	public Integer getNoOfDaysApplied() {
		return NoOfDaysApplied;
	}
	public void setNoOfDaysApplied(Integer noOfDaysApplied) {
		NoOfDaysApplied = noOfDaysApplied;
	}
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(Date appliedDate) {
		this.appliedDate = appliedDate;
	}
	public String getLeaveAppliedDate() {
		return leaveAppliedDate;
	}
	public void setLeaveAppliedDate(String leaveAppliedDate) {
		this.leaveAppliedDate = leaveAppliedDate;
	}
	public String getLeaveDateFrom() {
		return leaveDateFrom;
	}
	public void setLeaveDateFrom(String leaveDateFrom) {
		this.leaveDateFrom = leaveDateFrom;
	}
	public String getLeaveDateTo() {
		return leaveDateTo;
	}
	public void setLeaveDateTo(String leaveDateTo) {
		this.leaveDateTo = leaveDateTo;
	}
	@Override
	public String toString() {
		return "LeaveHistory [leaveId=" + leaveId + ", empId=" + empId
				+ ", leaveBalance=" + leaveBalance + ", NoOfDaysApplied="
				+ NoOfDaysApplied + ", dateFrom=" + dateFrom + ", dateTo="
				+ dateTo + ", status=" + status + ", appliedDate="
				+ appliedDate + ", leaveAppliedDate=" + leaveAppliedDate
				+ ", leaveDateFrom=" + leaveDateFrom + ", leaveDateTo="
				+ leaveDateTo + "]";
	}
	
	
}
