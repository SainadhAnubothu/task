package com.cg.employeemaintenancesystem.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.service.IEMSService;
import com.cg.employeemaintenancsystem.entity.Employee;

@Controller
public class EMSAdminController {
	@Autowired
	IEMSService empservice;

	@RequestMapping("AddEmployeePage")
	public ModelAndView addEmp() {
		ModelAndView view = new ModelAndView();
		Employee emp = new Employee();
		view.setViewName("AddEmployeePage");
		view.addObject("employee", emp);
		ArrayList<String> list = new ArrayList<>();
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		view.addObject("departmentList", list);
		ArrayList<String> gradeList = new ArrayList<>();
		gradeList.add("M1");
		gradeList.add("M2");
		gradeList.add("M3");
		gradeList.add("M4");
		gradeList.add("M5");
		gradeList.add("M6");
		gradeList.add("M7");
		view.addObject("gradeList", gradeList);
		return view;
	}

	@RequestMapping(value ="/insertDetails",method = RequestMethod.POST)
	public ModelAndView insertEmpDetails(
			@ModelAttribute("employee") Employee employee,Model m) {
		try {
			System.out.println("gyfwjHGJ");
			ModelAndView view = new ModelAndView();
			employee.setDepartmentId(Integer.parseInt(employee.getDeptId()));
			String fd = employee.getEmployeeDOB();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date date;
			date = sdf1.parse(fd);
			java.sql.Date sqlDateOfBirth = new java.sql.Date(date.getTime());
			employee.setDateOfBirth(sqlDateOfBirth);

			String td = employee.getEmployeeDOJ();
			date = sdf1.parse(td);
			java.sql.Date sqlDateOfJoin = new java.sql.Date(date.getTime());
			employee.setDateOfJoining(sqlDateOfJoin);
			System.out.println("above call");
			String empId = empservice.adminAddEmployee(employee);
			System.out.println(empId);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
}
