package com.cg.employeemaintenancesystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.service.IEMSService;
import com.cg.employeemaintenancsystem.entity.UserMaster;

@Controller
public class EMSLogInController {
	@Autowired
	IEMSService employeeService; 
	@RequestMapping("/index")
	public String welcome()
	{
		return "HomePage";
	}
	@RequestMapping("/loginDetails")
	public ModelAndView displaylogIn()
	{
		ModelAndView modelView=new ModelAndView();
		UserMaster userMaster=new UserMaster();
		modelView.setViewName("LoginPage");
		modelView.addObject("loginBean",userMaster);
		return modelView;
	}
	@RequestMapping(value="checkcredentials",method=RequestMethod.POST)
	public ModelAndView checkLoginDetails(@ModelAttribute("loginBean") UserMaster userMaster)
	{
		/*ArrayList<UserMaster> userDetails=employeeService.checkLoginCredentials(userMaster.getUserName(), userMaster.getUserPassword());*/
		ModelAndView modelView=new ModelAndView();
		/*UserMaster userType=userDetails.get(3);*/
		String user=null;
	/*	if(!userDetails.isEmpty())
		{
			for (UserMaster userType : userDetails) {
				user=userType.getUserType();
			}
			modelView.addObject("UserType",user);
			if("admin".equalsIgnoreCase("admin"))
				modelView.setViewName("AdminMainOptionPage");
			else
				modelView.setViewName("UserMainOptionPage");
		}
		else
		{
			modelView.addObject("loginBean",userMaster);
			modelView.setViewName("LoginPage");
		}*/
		if("admin".equalsIgnoreCase("admin"))
			modelView.setViewName("AdminMainOptionPage");
		return modelView;
	}
}
