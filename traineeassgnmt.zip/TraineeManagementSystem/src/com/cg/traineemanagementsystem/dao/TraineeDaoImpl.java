package com.cg.traineemanagementsystem.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineemanagementsystem.bean.LoginBean;
import com.cg.traineemanagementsystem.bean.Trainee;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao{

	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean validate(LoginBean lb) {
		// TODO Auto-generated method stub
		boolean res=false;
		Query query=entityManager.createNamedQuery("login");
		ArrayList<LoginBean> list=new ArrayList<>();
		list=(ArrayList<LoginBean>)query.getResultList();
		for (LoginBean loginBean : list) {
			if((lb.getuName().equals(loginBean.getuName())) && (lb.getuPassword().equals(loginBean.getuPassword()))){
				System.out.println(loginBean.getuName()+" "+loginBean.getuPassword());
				res=true;
			}
		}
		return res;
	}

	@Override
	public void insertData(Trainee tr) {
		entityManager.persist(tr);
		entityManager.flush();
	}

	@Override
	public ArrayList<Trainee> removeDataview(Integer tId) {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("deleteview").setParameter("id",tId);
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}

	@Override
	public void removeData(Integer tId) {
		// TODO Auto-generated method stub
		Trainee t=entityManager.find(Trainee.class, tId);
		entityManager.remove(t);
		entityManager.flush();
	}

	@Override
	public ArrayList<Trainee> modifydata(Integer tId) {
		Query query=entityManager.createNamedQuery("modifydataview").setParameter("id1",tId);
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}

	@Override
	public void modify(Trainee t) {
		// TODO Auto-generated method stub
		entityManager.merge(t);
		entityManager.flush();
	}

	@Override
	public ArrayList<Trainee> retrieveone(Integer tId) {
		Query query=entityManager.createNamedQuery("retrieveoneview").setParameter("id1",tId);
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<Trainee> retrieveall() {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("retrieveallview");
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}
	
}
