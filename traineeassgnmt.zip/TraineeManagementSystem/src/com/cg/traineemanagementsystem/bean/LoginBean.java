package com.cg.traineemanagementsystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="login_data")
@NamedQueries({@NamedQuery(name="login",query="select l from LoginBean l")})
public class LoginBean {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="u_id")
	private Integer uId;
	@Column(name="u_name")
	private String uName;
	@Column(name="u_pwd")
	private String uPassword;

	
	public Integer getuId() {
		return uId;
	}

	public void setuId(Integer uId) {
		this.uId = uId;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuPassword() {
		return uPassword;
	}

	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}

}
