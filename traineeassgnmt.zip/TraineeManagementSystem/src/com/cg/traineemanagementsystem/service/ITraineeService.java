package com.cg.traineemanagementsystem.service;

import java.util.ArrayList;

import com.cg.traineemanagementsystem.bean.LoginBean;
import com.cg.traineemanagementsystem.bean.Trainee;

public interface ITraineeService {
public boolean validate(LoginBean lb);
public void insertData(Trainee tr);
public ArrayList<Trainee> removeDataview(Integer tId);
public void removeData(Integer tId);
public ArrayList<Trainee> modifydata(Integer tId);
public void modify(Trainee t);
public ArrayList<Trainee> retrieveone(Integer tId);
public ArrayList<Trainee> retrieveall();
}
