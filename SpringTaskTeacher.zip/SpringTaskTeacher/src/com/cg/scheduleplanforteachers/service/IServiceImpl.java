package com.cg.scheduleplanforteachers.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.scheduleplanforteacher.bean.Teacher;
import com.cg.scheduleplanforteacher.dao.IDao;

@Service("service")
public class IServiceImpl implements Iservice{

	@Autowired
	IDao dao;
	@Override
	public void insertDetails(Teacher plan) {
		dao.insertDetails(plan);
	}
	
	
}

