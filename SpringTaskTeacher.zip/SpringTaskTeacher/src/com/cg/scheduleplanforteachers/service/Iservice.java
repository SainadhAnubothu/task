package com.cg.scheduleplanforteachers.service;

import com.cg.scheduleplanforteacher.bean.Teacher;

public interface Iservice {
public void insertDetails(Teacher plan);
}
