package com.cg.scheduleplanforteacher.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.cg.scheduleplanforteacher.bean.Teacher;

@Repository("dao")
@Transactional
public class IDAOImpl implements IDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void insertDetails(Teacher plan) {
		// TODO Auto-generated method stub
		entityManager.persist(plan);
		entityManager.flush();
	}


}
