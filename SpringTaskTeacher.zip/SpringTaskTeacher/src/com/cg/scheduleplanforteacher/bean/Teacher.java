package com.cg.scheduleplanforteacher.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="teacher_plan")
public class Teacher {

	public Teacher() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="fac_id")
	private Integer facId;
	@Column(name="fac_name")
	@NotEmpty(message="Field should not be empty")
	private String facultyName;
	@Column(name="date")
	private String date;
	@Column(name="fac_expert_in")
	@NotEmpty(message="Field should not be empty")
	private String facExpertIn;
	@Column(name="period")
	@NotEmpty(message="Field should not be empty")
	private String period;
	@Column(name="comments")
	private String comments;
	@Column(name="mail")
	@NotEmpty(message="Field should not be empty")
	@Pattern(regexp="[A-Za-z0-9]+@[A-Za-z0-9-]+[.][A-Aa-z]{2,4}",message="Enter valid mailid")
	private String mailId;
	public Integer getFacId() {
		return facId;
	}
	public void setFacId(Integer facId) {
		this.facId = facId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getFacExpertIn() {
		return facExpertIn;
	}
	public void setFacExpertIn(String facExpertIn) {
		this.facExpertIn = facExpertIn;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	

}
