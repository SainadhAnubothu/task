package com.cg.employeemaintenancesystem.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.service.IEMSService;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;

@Controller
public class EMSAdminController {
	@Autowired
	IEMSService empservice;
	@RequestMapping(value="AddEmployeePage")
	public ModelAndView addEmp(@RequestParam String name)
	{
		ModelAndView view = new ModelAndView();
		Employee emp = new Employee();
		view.setViewName("AddEmployeePage");
		view.addObject("employee", emp);
		view.addObject("name",name);
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		view.addObject("departmentList", list);
		ArrayList<String> gradeList = new ArrayList<>();
		gradeList.add("M1");
		gradeList.add("M2");
		gradeList.add("M3");
		gradeList.add("M4");
		gradeList.add("M5");
		gradeList.add("M6");
		gradeList.add("M7");
		view.addObject("gradeList", gradeList);
		return view;
	}

	@RequestMapping(value ="/insertDetails",method = RequestMethod.POST)
	public ModelAndView insertEmployeeDetails(@RequestParam String name,
			@ModelAttribute("employee") @Valid Employee employee,BindingResult bindingResult) {
		System.out.println("insert details");
		ModelAndView view = new ModelAndView();
		System.out.println("insert details");
		view.addObject("name",name);
		try {
			System.out.println("insert details");
			if(bindingResult.hasErrors())
			{
				System.out.println("insert details");
				ArrayList<Integer> list = new ArrayList<>();
				list.add(1);
				list.add(2);
				list.add(3);
				list.add(4);
				view.addObject("departmentList", list);
				ArrayList<String> gradeList = new ArrayList<>();
				gradeList.add("M1");
				gradeList.add("M2");
				gradeList.add("M3");
				gradeList.add("M4");
				gradeList.add("M5");
				gradeList.add("M6");
				gradeList.add("M7");
				view.addObject("gradeList", gradeList);
				view.addObject("name",name);
				view.setViewName("AddEmployeePage");
				
			}
			else
			{
			String fd = employee.getEmployeeDOB();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date date;
			date = sdf1.parse(fd);
			java.sql.Date sqlDateOfBirth = new java.sql.Date(date.getTime());
			employee.setDateOfBirth(sqlDateOfBirth);

			String td = employee.getEmployeeDOJ();
			date = sdf1.parse(td);
			java.sql.Date sqlDateOfJoin = new java.sql.Date(date.getTime());
			employee.setDateOfJoining(sqlDateOfJoin);
			String empId = empservice.adminAddEmployee(employee);
			view.addObject("message", empId+"inserted successfully!!");
			view.addObject("name",name);
			view.setViewName("Success");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return view;
	}
	@RequestMapping(value="DisplayEmployeePage")
	public ModelAndView displayEmployeesDetails() {
		ModelAndView view=new ModelAndView();
		view.setViewName("AllDetails");
		ArrayList<Employee> emplist=new ArrayList<>();
		emplist=empservice.adminDisplayAllEmployees();
		view.addObject("details", emplist);
		return view;
	}
	
	@RequestMapping(value="ModifyEmployeePage")
	public ModelAndView verifyEmployeeId() {
		ModelAndView view=new ModelAndView();
		Employee emp=new Employee();
		view.addObject("employee",emp);
		view.setViewName("ModifyEmployeePage");
		return view;		
	}
	@RequestMapping(value="modifySearch")
	public ModelAndView modifyEmployee(@ModelAttribute("employee") Employee employee) {
		ModelAndView view=new ModelAndView();
		Employee emp=new Employee();
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		view.addObject("departmentList", list);
		ArrayList<String> gradeList = new ArrayList<>();
		gradeList.add("M1");
		gradeList.add("M2");
		gradeList.add("M3");
		gradeList.add("M4");
		gradeList.add("M5");
		gradeList.add("M6");
		gradeList.add("M7");
		view.addObject("gradeList", gradeList);
		view.addObject("employee",emp);
		System.out.println(employee.getEmployeeId());
		ArrayList<Employee> empList=empservice.userIdSearchEmployee(employee.getEmployeeId());
		
		view.addObject("e",empList);
		System.out.println(empList);
		view.setViewName("Modify2");
		return view;		
	}
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public ModelAndView modifyEmployeeDetails(@ModelAttribute("employee") Employee employee){
		ModelAndView view=new ModelAndView();
		System.out.println(employee);
		view.addObject("message",empservice.adminModifyEmployee(employee)+" Modified succesfully!!!");
		view.setViewName("Success");
		return view;
	}
	@RequestMapping(value="/DisplayAppliedLeaves")
	public ModelAndView displayAppliedLeaves(HttpSession session){
		ModelAndView view=new ModelAndView();
		String userId=(String) session.getAttribute("userId");
		ArrayList<LeaveHistory> list=new ArrayList<>();
		list=empservice.adminDisplayLeaves(userId);
		if(list.isEmpty())
		{
			String message="You have no pending leaves to approve!!";
			view.addObject("message",message);
			view.setViewName("Success");
		}
		else{
		view.addObject("displayList",list);
		view.setViewName("Success");
		}
		return view;	
	}
	@RequestMapping(value="/decision")
	public ModelAndView statusUpdate(@RequestParam("decision") String decision,@RequestParam("leaveId") Integer leaveId,@RequestParam("leaveBalance") Integer leaveBalance,@RequestParam("noOfDaysApplied") Integer noOfDaysApplied,HttpSession session){
		ModelAndView view=new ModelAndView();
		if(decision.equals("Approve"))
		{
			decision="approved";
		}
		else
		{
			decision="rejected";
		}
		Integer id=empservice.adminApproveLeave(leaveId, decision,leaveBalance,noOfDaysApplied);
		String userId=(String) session.getAttribute("userId");
		ArrayList<LeaveHistory> list=new ArrayList<>();
		list=empservice.adminDisplayLeaves(userId);
		if(list.isEmpty())
		{
			String message="You have no pending leave to approve!!";
			view.addObject("message",message);
			view.setViewName("Success");
		}
		else{
		view.addObject("displayList",list);
		view.setViewName("Success");
		}
		return view;
	}
}
