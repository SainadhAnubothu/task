package com.cg.employeemaintenancesystem.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.entity.UserMaster;
import com.cg.employeemaintenancesystem.service.IEMSService;

@Controller
public class EMSLogInController {
	@Autowired
	IEMSService employeeService; 
	@RequestMapping("/index")
	public String welcome()
	{
		return "HomePage";
	}
	@RequestMapping("/Logout")
	public String logout()
	{
		return "LogOut";
	}
	@RequestMapping("/AdminMainOptionPage")
	public String admin()
	{
		return "AdminMainOptionPage";
	}
	@RequestMapping("/UserMainOptionPage")
	public String user()
	{
		return "UserMainOptionPage";
	}
	@RequestMapping("/loginDetails")
	public ModelAndView displaylogIn()
	{
		ModelAndView modelView=new ModelAndView();
		UserMaster userMaster=new UserMaster();
		modelView.setViewName("LoginPage");
		modelView.addObject("loginBean",userMaster);
		return modelView;
	}
	@RequestMapping(value="checkcredentials",method=RequestMethod.POST)
	public ModelAndView checkLoginDetails(@ModelAttribute("loginBean") @Valid UserMaster userMaster,BindingResult br,HttpSession session)
	{
		ModelAndView view=new ModelAndView();
		if(br.hasErrors()){
			view.setViewName("LoginPage");
		}
		else{
		ArrayList<UserMaster> userDetails=employeeService.checkLoginCredentials(userMaster.getUserName(), userMaster.getUserPassword());
		
		String user=null;
		if(!userDetails.isEmpty())
		{
			for (UserMaster userType : userDetails) {
				user=userType.getUserType();
				session.setAttribute("userId", userType.getUserId());
				session.setAttribute("name",userType.getUserName());
			if("admin".equalsIgnoreCase(user))
				view.setViewName("AdminMainOptionPage");
			else
				view.setViewName("UserMainOptionPage");
			}
		}
		else
		{
			view.addObject("loginBean",userMaster);
			view.addObject("message", "Invalid Credentials!!!");
			view.setViewName("LoginPage");
		}
		}
		return view;
	}
}
