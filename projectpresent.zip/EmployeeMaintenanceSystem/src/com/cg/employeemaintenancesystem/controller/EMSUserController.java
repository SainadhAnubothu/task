package com.cg.employeemaintenancesystem.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.service.IEMSService;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;

@Controller
public class EMSUserController {
	@Autowired
	IEMSService employeeService;

	@RequestMapping(value = "/SearchEmployee")
	public ModelAndView searchPage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("Search");
		return view;
	}

	@RequestMapping(value = "/employeeIdSearch")
	public ModelAndView employeeIdSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("IdSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeIdSearchDetails")
	public ModelAndView getIdSearchDetails(
			@RequestParam("employeeid") String employeeId) {
		ModelAndView view = new ModelAndView();

		ArrayList<Employee> employeelist = employeeService
				.userIdSearchEmployee(employeeId);

		view.addObject("employeeData",employeelist);
		view.addObject("message","There are no employees with the given employee Id");
		view.setViewName("IdSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeFirstNameSearch")
	public ModelAndView employeeFirstNameSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("FirstnameSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeFirstNameSearchDetails")
	public ModelAndView getFirstNameSearchDetails(
			@RequestParam("firstName") String firstName) {
		ModelAndView view = new ModelAndView();

		ArrayList<Employee> employeelist = employeeService
				.userFirstNameSearchEmployee(firstName);

		view.addObject("employeeData",employeelist);
		view.addObject("message","There are no employees with the given first name");
		view.setViewName("FirstnameSearchPage");
		return view;
	}

	@RequestMapping(value = "/searchbylname")
	public ModelAndView employeeLastNameSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("LastNameSearchpage");
		return view;
	}

	@RequestMapping(value = "/employeeLastNameSearchDetails")
	public ModelAndView getLastNameSearchDetails(
			@RequestParam("lastName") String lastName) {
		ModelAndView view = new ModelAndView();

		ArrayList<Employee> employeelist = employeeService
				.userLastNameSearchEmployee(lastName);
		System.out.println(employeelist);
		view.addObject("employeeData",employeelist);
		view.addObject("message","There are no employees with the given last name");
		view.setViewName("LastNameSearchpage");
		return view;
	}

	@RequestMapping(value = "/employeeGradeSearch")
	public ModelAndView employeeGradeSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("GradeSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeGradeSearchDetails")
	public ModelAndView getGradeSearchDetails(
			@RequestParam("grade") String[] grade) {
		ModelAndView view = new ModelAndView();
		ArrayList<Employee>[] employeeData = (ArrayList<Employee>[]) new ArrayList[10];
		Integer length = grade.length;
		for (Integer index = 0; index < length; index++) {
			employeeData[index] = employeeService
					.userGradeSearchEmployee(grade[index]);
		}
		view.addObject("employeeData", employeeData);
		view.setViewName("GradeSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeDepartmentSearch")
	public ModelAndView employeeDepartmentSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("DepartmentSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeDepartmentSearchDetails")
	public ModelAndView getDepartmentSearchDetails(
			@RequestParam("department") String[] department) {
		ModelAndView view = new ModelAndView();
		ArrayList<Employee>[] employeeData = (ArrayList<Employee>[]) new ArrayList[10];
		Integer length = department.length;
		for (Integer index = 0; index < length; index++) {
			employeeData[index] = employeeService
					.userDepartmentSearchEmployee(Integer.parseInt(department[index]));
			
			
		}
		
		view.addObject("employeeData", employeeData);
		view.setViewName("DepartmentSearchPage");
		return view;
	}
	
	
	@RequestMapping(value = "/employeeMaritalStatusSearch")
	public ModelAndView employeeMaritalStatusSearch() {
		ModelAndView view = new ModelAndView();
		view.setViewName("MaritalStatusSearchPage");
		return view;
	}

	@RequestMapping(value = "/employeeMaritalStatusSearchDetails")
	public ModelAndView getMaritalStatusSearchDetails(
			@RequestParam("marital") String[] marital) {
		ModelAndView view = new ModelAndView();
		ArrayList<Employee>[] employeeData = (ArrayList<Employee>[]) new ArrayList[10];
		Integer length = marital.length;
		System.out.println(length);
		for (Integer index = 0; index < length; index++) {
			System.out.println(marital[index]);
			employeeData[index] = employeeService.userMaritalStatusSearchEmployee(marital[index]);
			System.out.println(employeeData[index]);
		}
		view.addObject("employeeData", employeeData);
		view.addObject("index", length);
		view.setViewName("MaritalStatusSearchPage");
		return view;
	}
	@RequestMapping(value = "/ApplyLeave")
	public ModelAndView employeeApplyLeave() {
		ModelAndView view = new ModelAndView();
		view.addObject("applyLeave",new LeaveHistory());
		view.setViewName("ApplyLeave");
		return view;
	}
	@RequestMapping(value = "/applyleave")
	public ModelAndView applyLeave(@ModelAttribute("applyLeave") LeaveHistory leaveHistory,HttpSession session) {
		ModelAndView view = new ModelAndView();
		try {
		String fromDate = leaveHistory.getLeaveDateFrom();
		SimpleDateFormat dateformatDate = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date;
		
			date = dateformatDate.parse(fromDate);
		
		java.sql.Date sqlFromDate = new java.sql.Date(date.getTime());
		leaveHistory.setDateFrom(sqlFromDate);

		String toDate = leaveHistory.getLeaveDateTo();
		date = dateformatDate.parse(toDate);
		java.sql.Date sqlToDate = new java.sql.Date(date.getTime());
		leaveHistory.setDateTo(sqlToDate);
		leaveHistory.setEmpId((String)session.getAttribute("userId"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String leaveMessage=employeeService.userApplyLeave(leaveHistory);
		view.addObject("LeaveMessage",leaveMessage);
		view.setViewName("ApplyLeave");
		return view;
	}
	@RequestMapping(value="/checkleavestatus")
	public ModelAndView leavestatus(HttpSession session) {
		System.out.println("leave status");
		ModelAndView view=new ModelAndView();
		String id=(String)session.getAttribute("userId");
		ArrayList<LeaveHistory> list=new ArrayList<>();
		list=employeeService.userLeaveStatusCheck(id);
		if(list.isEmpty()) {
			view.addObject("message", "You have no applied Leaves!!");
		}else {
			view.addObject("leaveData", list);
		}

		view.setViewName("leavesatus");
		return view;
	}
}
