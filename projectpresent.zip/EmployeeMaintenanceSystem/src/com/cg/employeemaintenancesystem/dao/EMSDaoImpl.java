package com.cg.employeemaintenancesystem.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;
import com.cg.employeemaintenancesystem.entity.UserMaster;

@Repository
@Transactional
public class EMSDaoImpl implements IEMSDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public ArrayList<UserMaster> checkLoginCredentials(String userName, String userPassword) {
		Query query=entityManager.createNamedQuery("checkLogin");
		query.setParameter("userName", userName);
		query.setParameter("userPassword", userPassword);
		ArrayList<UserMaster> userDetails=(ArrayList<UserMaster>) query.getResultList();
		return userDetails;
	}

	@Override
	public String adminAddEmployee(Employee employee) {
		System.out.println("in dao:"+employee);
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmployeeId();
	}

	@Override
	public String adminModifyEmployee(Employee employee) {
		entityManager.merge(employee);
		entityManager.flush();
		return employee.getEmployeeId();
	}

	@Override
	public ArrayList<Employee> adminDisplayAllEmployees() {
		ArrayList<Employee> displayAllEmployees=(ArrayList<Employee>) entityManager.createNamedQuery("displayAll").getResultList();
		return displayAllEmployees;
	}

	@Override
	public ArrayList<LeaveHistory> adminLeaveDecision(String userId,
			String decision) {
		return null;
	}

	@Override
	public ArrayList<Employee> userIdSearchEmployee(String employeeId) {
		System.out.println(employeeId);
		ArrayList<Employee> idSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("idSearch").setParameter("employeeId", employeeId).getResultList();
		return idSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userFirstNameSearchEmployee(String firstName) {
		// TODO Auto-generated method stub
		ArrayList<Employee> firstNameSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("firstNameSearch").setParameter("firstName", firstName).getResultList();
		return firstNameSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userLastNameSearchEmployee(String lastName) {
		// TODO Auto-generated method stub
		ArrayList<Employee> lastNameSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("lastNameSearch").setParameter("lastName", lastName).getResultList();
		return lastNameSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userGradeSearchEmployee(String gradeCode) {
		// TODO Auto-generated method stub
		System.out.println(gradeCode);
		ArrayList<Employee> gradeSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("gradeSearch").setParameter("grade", gradeCode).getResultList();
		
		return gradeSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userDepartmentSearchEmployee(
			Integer department) {
		// TODO Auto-generated method stub
		System.out.println(department);
		ArrayList<Employee> departmentSearchEmployee=(ArrayList<Employee>) entityManager.createQuery("select e from Employee e where e.departmentId=:department").setParameter("department", department).getResultList();
		for (Employee employee : departmentSearchEmployee) {
			System.out.println(employee.getEmployeeId()+employee.getFirstName());
		}
		return departmentSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userMaritalStatusSearchEmployee(
			String maritalStatus) {
		// TODO Auto-generated method stub
		ArrayList<Employee> maritalStatusSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("maritalStatusSearch").setParameter("maritalStatus", maritalStatus).getResultList();
		return maritalStatusSearchEmployee;
	}

	@Override
	public String userApplyLeave(LeaveHistory leaveHistory) {
		// TODO Auto-generated method stub
		leaveHistory.setStatus("applied");
		LocalDate localDate=LocalDate.now();
		Date applieDate = Date.valueOf(localDate); 
		leaveHistory.setAppliedDate(applieDate);
		Query query1=entityManager.createQuery("select min(leave.leaveBalance) from LeaveHistory leave where leave.empId=:employeeId and leave.status=:status");
		query1.setParameter("employeeId", leaveHistory.getEmpId());
		query1.setParameter("status", "applied");
		ArrayList<Integer> list1=(ArrayList<Integer>) query1.getResultList();
		String result=null;
		if(list1.get(0)==null)
		{
			query1.setParameter("status", "approved");
			ArrayList<Integer> list2=(ArrayList<Integer>) query1.getResultList();
			if(list2.get(0)==null)
			{
				if(12-leaveHistory.getNoOfDaysApplied()<0)
				{
					result="Your Leave Balance is "+12+" You cant apply Leave more than your Leave Balance";
				}
				else {
				leaveHistory.setLeaveBalance(12);
				entityManager.persist(leaveHistory);
				entityManager.flush();
				result= "Leave applied successfully!!! Your Leave Id is "+leaveHistory.getLeaveId();
				}
			}
			else {
				if((list2.get(0) -leaveHistory.getNoOfDaysApplied())<0)
				{
						result="Your Leave Balance is "+list2.get(0)+" You cant apply Leave more than your Leave Balance";
				}
				else {
					leaveHistory.setLeaveBalance(list2.get(0));
					entityManager.persist(leaveHistory);
					entityManager.flush();
					result= "Leave applied successfully!!! Your Leave Id is "+leaveHistory.getLeaveId();
				}
			}
		}
		else {
			result="You have pending leave and you cannot apply for other leave!!!";
		}
		return result;
	}

	@Override
	public ArrayList<LeaveHistory> adminDisplayLeaves(String userId) {
		Query query=entityManager.createQuery("SELECT l FROM LeaveHistory l ,Employee e WHERE e.employeeId = l.empId and e.mgrId=:userId and status=:status");
		query.setParameter("userId", userId);
		query.setParameter("status","applied");
		ArrayList<LeaveHistory> list=(ArrayList<LeaveHistory>) query.getResultList();
		return list;
	}
	@Override
	@Modifying
	public Integer adminApproveLeave(Integer leaveId,String decision,Integer leaveBalance,Integer noOfDaysApplied) {
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("update LeaveHistory leave set leave.leaveBalance=:balance,leave.status=:status where leave.leaveId=:leaveId");
		query.setParameter("status", decision);
		query.setParameter("leaveId", leaveId);
		if(decision.equals("approved"))
			query.setParameter("balance", (leaveBalance-noOfDaysApplied));
		else if(decision.equals("rejected"))
			query.setParameter("balance", leaveBalance);
		query.executeUpdate();
		return leaveId;
	}

	@Override
	public ArrayList<LeaveHistory> userLeaveStatusCheck(String userId) {
		// TODO Auto-generated method stub
		ArrayList<LeaveHistory> list=(ArrayList<LeaveHistory>) entityManager.createQuery("select l from LeaveHistory l where l.empId=:id").setParameter("id", userId).getResultList();
		return list;
	}
}
